using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System.IO;

namespace SeleniumCsharp
{
    [TestClass]
    public class UnitTest1
    {
        
        public static void Main(string[] args)
        {
            UnitTest1 unit = new UnitTest1();
            unit.TestMethod1();
        }
        [TestMethod]
        public void TestMethod1()
        {
            var service = ChromeDriverService.CreateDefaultService(@"j:\WebScraping\chromedriver-win64");

            // configure chrome capabilities
            var options = new ChromeOptions();
            options.BinaryLocation = @"j:\WebScraping\chrome-win64\chrome.exe";

            // create driver
            var driver = new ChromeDriver(service, options);

            DateTime timeStart = DateTime.Now;
            Console.WriteLine(timeStart.ToLongTimeString());

            List<String> motifs = new List<String>();

            //Create instance of ChromeOptions Class
            ChromeOptions handlingSSL = new ChromeOptions();

            //Using the accept insecure cert method with true as parameter to accept the untrusted certificate
            handlingSSL.AcceptInsecureCertificates = true;
            
            driver.Url = "https://epd.expasy.org/epd/EPDnew_database.php";
            //database: H. sapiens - 1
            //database: Macaca mulatta - 3
            //database: M. musculus - 4
            //database: R. norvegicus - 6
            //database: A. thaliana - 13
            SelectElement dbSelect = new SelectElement(driver.FindElement(By.Id("db")));
            dbSelect.SelectByIndex(13);
            IWebElement db = dbSelect.SelectedOption;
            String database = db.Text;

            String[] queries = {
            "AT5G10140_1",
            "AT2G45660_1",
            "AT4G35900_1",
            "AT5G61850_1",
            "AT5G03840_1",
            "AT1G69120_1",
            "AT4G36920_1",
            "AT3G54340_1",
            "AT5G20240_1",
            "AT5G15800_1",
            "AT3G02310_1",
            "AT1G24260_1",
            "AT2G03710_1",
            "AT5G60910_1",
            "AT2G22540_1",
            "AT4G24540_1",
            "AT4G18960_1"
            };

            String query;
            IWebElement ucp;
            IWebElement search;
            SelectElement motiflibSelect;
            IWebElement submotiflibSelect;
            IWebElement motifLib;
            String motiflib;
            SelectElement plotfromSelect;
            IWebElement From;
            String from;
            SelectElement plottoSelect;
            IWebElement To;
            String to;
            SelectElement motifcutoffSelect;
            IWebElement p;
            String p_value;
            SelectElement motifSelect;
            IList<IWebElement> list;
            IWebElement motifSearch;
            IWebElement result;
            Boolean wait;
            String head;
            String f;
            Task asyncTask;
            DateTime timeStop;

            foreach (String q in queries)
            {
                motifs.Clear();
                query = q;
                ucp = driver.FindElement(By.Id("query"));
                ucp.SendKeys(query);

                //epdsubmit: SEARCH
                search = driver.FindElement(By.ClassName("epdsubmit"));
                search.Click();

                //Select Motif Library: Taranscription Factor Motifs (1)
                motiflibSelect = null;
                submotiflibSelect = null;
                try
                {
                    motiflibSelect = new SelectElement(driver.FindElement(By.Id("motifLibrary")));
                }
                catch (NoSuchElementException e)
                {
                    ///html/body/div[2]/div[5]/div[3]/div[2]/form/div/table/tbody/tr[2]/td[2]/a
                    submotiflibSelect = driver.FindElement(By.XPath("/html/body/div[2]/div[5]/div[3]/div[2]/form/div/table/tbody/tr[2]/td[2]/a"));
                    submotiflibSelect.Click();
                    motiflibSelect = new SelectElement(driver.FindElement(By.Id("motifLibrary")));
                }
                motiflibSelect.SelectByIndex(1);
                motifLib = motiflibSelect.SelectedOption;
                motiflib = motifLib.Text;

                //From: -5000 (2)
                plotfromSelect = new SelectElement(driver.FindElement(By.Id("plotFrom")));
                plotfromSelect.SelectByIndex(2);
                From = plotfromSelect.SelectedOption;
                from = From.Text;

                //To: 1000 (1)
                plottoSelect = new SelectElement(driver.FindElement(By.Id("plotTo")));
                plottoSelect.SelectByIndex(1);
                To = plottoSelect.SelectedOption;
                to = To.Text;

                //p-value of: 0.0001, 0.00001 (2) (3)
                motifcutoffSelect = new SelectElement(driver.FindElement(By.Id("motifCutoff")));
                motifcutoffSelect.SelectByIndex(3);
                p = motifcutoffSelect.SelectedOption;
                p_value = p.Text;

                //Select Motif: all        
                motifSelect = new SelectElement(driver.FindElement(By.Id("p_tf")));
                System.Threading.Thread.Sleep(1000);
                list = motifSelect.Options;

                int size = list.Count();
                for (int i = 0; i < size; i++)
                {
                    motifSelect.SelectByIndex(i);
                    //plotGene(): SEARCH
                    motifSearch = driver.FindElement(By.XPath("/html/body/div[2]/div[4]/div[3]/div[2]/table[5]/tbody/tr[3]/td/input"));
                    motifSearch.Click();

                    //Read result
                    System.Threading.Thread.Sleep(3000);

                    do
                        try
                        {
                            wait = false;
                            result = driver.FindElement(By.XPath("//div[@id='plotGene']/p[1]"));
                            if (result.Text.Length != 0)
                                motifs.Add(result.Text);
                            else
                                wait = true;
                        }
                        catch (Exception)
                        {
                            wait = true;
                            System.Threading.Thread.Sleep(3000);
                        }
                    while (wait);

                }

                head = "database:" + database + " query:" + query + " Library:" + motiflib + " From:" + from + " To:" + to + " p-value:" + p_value;
                f = "C:\\Adatok\\Debrecen\\" + database + "-" + query + "-" + p_value + ".txt";
                asyncTask = writetofile(head, f, motifs);
                asyncTask.Wait();
                timeStop = DateTime.Now;
                Console.WriteLine(timeStop.ToLongTimeString());
            }
            driver.Close();
            driver.Quit();
        }

        private static async Task writetofile(String head, String f, List<String> motifs)
        {
            try
            {
                StreamWriter streamWriter = new StreamWriter(f);
                streamWriter.WriteLine(head);
                foreach (String row in motifs)
                {
                    String m = row.Substring(0, row.IndexOf(" "));
                    String r = row.Substring(row.LastIndexOf(": ") + 2);
                    String[] numbers = r.Split(',');
                    String outrow = m.Trim();
                    for (int i = 0; i < numbers.Length; i++)
                    {
                        outrow += "\t" + numbers[i].Trim();
                    }
                    await streamWriter.WriteLineAsync(outrow);
                }
                streamWriter.Close();
                streamWriter = null;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
